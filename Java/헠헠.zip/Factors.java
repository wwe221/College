import java.util.Scanner;

public class Factors
{
	public static void main(String[] args)
	{
		int first ,last, num, start, end;
		Scanner scan = new Scanner(System.in);

		System.out.print("Input a First : ");
		first = scan.nextInt();
		System.out.print("Input a Last : ");
		last = scan.nextInt();
		System.out.print("Input a Num : ");
		num = scan.nextInt();	

		if(first>last)
		{	
			start = last;
			end = first;
		}
		else
		{
			start = first;
			end = last;
		}

		for(int i=start;i<=end;i++)
		{
			if(i==num)
			{	
				System.out.println(start + " And " + end + " Between " + num + " Exist!!");
				return;
			}	
		}
		System.out.println(start + " And " + end + " Between " + num + " Not Exist!!");
	}
}

		
			
				