import java.util.Scanner;
import java.util.Random;

public class Rock
{
	public static void main(String[] args)
	{
		String personPlay; 
		String computerPlay; 
		int computerInt; 
				 
		Scanner scan = new Scanner(System.in);
		Random generator = new Random();

		computerInt = generator.nextInt(3);

		System.out.println ("Choice 'R', 'P', 'S': ");
		personPlay = scan.nextLine();
		personPlay = personPlay.toUpperCase();
		
		System.out.println(computerInt);

		switch(computerInt)
		{
			case 0:
				computerPlay = "R";
				break;
			case 1:
				computerPlay = "S";
				break;
			default:
				computerPlay = "P";
				break;
		}

		if(personPlay.equals(computerPlay))
			System.out.println("It's a tie!");
		else if(personPlay.equals("R"))
		{
			if(computerPlay.equals("S"))
				System.out.println("Rock crushes scissors. You Win!!");
			else if(computerPlay.equals("P"))
				System.out.println("Papers crush Rock. You Lose!!");
		}
		else if(personPlay.equals("S"))
		{
			if(computerPlay.equals("R"))
				System.out.println("Rock crushes scissors. You Lose!!");
			else if(computerPlay.equals("P"))
				System.out.println("Scissors crush papers. You Win!!");
		}
		else if(personPlay.equals("P"))
		{
			if(computerPlay.equals("R"))
				System.out.println("Papers crush rock. You Win!!");
			else if(computerPlay.equals("S"))
				System.out.println("Scissors crush papers. You Lose!!");
		}
				
	}
}