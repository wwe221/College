public class StudentGrades
{
public static void main (String[] args)
{
System.out.println ("///////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
System.out.println ("====\tStudent Points\t====");
System.out.println ("///////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
System.out.println ("Name\tMath	JAVA	Total");
System.out.println ("----\t---\t----\t-----");
System.out.println ("Lee\t50\t9\t59");
System.out.println ("Kim\t44\t5\t49");
System.out.println ("What\t30\t4\t34");
System.out.println ("The\t42\t8\t50");
System.out.println ("Hell\t26\t7\t33");
}
}