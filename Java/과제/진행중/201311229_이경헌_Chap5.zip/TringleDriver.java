
public class TringleDriver {

	public static void main(String [] args)
	{
		Tringle tri = new Tringle(3,4);
		System.out.println(tri.getarea());
		tri.sethigh(5);
		tri.setmit(7);
		System.out.println(tri.getarea());
	}
}
